<?php ?>
<h2>Pemesanan Telur Asin</h2>
<form action="proses_pesan.php" method="POST">
Nama:<br><input name="nama"><br>
Alamat:<br><textarea name="alamat"></textarea><br>
No Telp:<br><input name="telp"><br>
Jumlah:<br><input type="number" name="jumlah"><br>
Untuk Tanggal:<br><input type="date" name="tgl_kirim"><br><br>
<button>Pesan Sekarang</button>
</form>
