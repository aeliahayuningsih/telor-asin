<h2>Pesanan berhasil dibuat</h2>
<p>Terima kasih telah memesan telur asin.</p>