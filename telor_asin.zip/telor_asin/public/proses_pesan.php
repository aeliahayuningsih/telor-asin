<?php
include '../config/koneksi.php';

$nama=$_POST['nama'];
$alamat=$_POST['alamat'];
$telp=$_POST['telp'];
$jumlah=$_POST['jumlah'];
$tgl_kirim=$_POST['tgl_kirim'];
$total=$jumlah*3000;

mysqli_query($conn,"INSERT INTO pesanan VALUES(NULL,'$nama','$alamat','$telp',NOW(),'$tgl_kirim','$jumlah','$total','Menunggu')");

header("location:selesai.php");
?>