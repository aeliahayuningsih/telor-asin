CREATE DATABASE telor_asin;
USE telor_asin;

CREATE TABLE admin(
id_admin INT AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(50),
password VARCHAR(255)
);

INSERT INTO admin(username,password) VALUES('admin',MD5('admin123'));

CREATE TABLE produk(
id_produk INT AUTO_INCREMENT PRIMARY KEY,
nama_produk VARCHAR(100),
stok INT,
tanggal_produksi DATE,
harga INT
);

INSERT INTO produk VALUES
(NULL,'Telur Asin Original',100,CURDATE(),3000);

CREATE TABLE pesanan(
id_pesanan INT AUTO_INCREMENT PRIMARY KEY,
nama VARCHAR(100),
alamat TEXT,
no_telp VARCHAR(20),
tanggal_pesan DATE,
tanggal_kirim DATE,
jumlah INT,
total INT,
status VARCHAR(30)
);

CREATE TABLE pengantaran(
id_antar INT AUTO_INCREMENT PRIMARY KEY,
id_pesanan INT,
nama_pengantar VARCHAR(100),
tanggal_antar DATE,
jam TIME
);

CREATE TABLE pembayaran(
id_bayar INT AUTO_INCREMENT PRIMARY KEY,
id_pesanan INT,
metode VARCHAR(20),
tanggal_bayar DATE
);
