<?php
$conn=mysqli_connect("localhost","root","","telor_asin");
if(!$conn){ die("Database gagal terkoneksi"); }
?>