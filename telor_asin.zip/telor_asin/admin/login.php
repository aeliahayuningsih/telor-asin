<?php
session_start();
include '../config/koneksi.php';

if(isset($_POST['login'])){
$user=$_POST['username'];
$pass=md5($_POST['password']);

$q=mysqli_query($conn,"SELECT * FROM admin WHERE username='$user' AND password='$pass'");

if(mysqli_num_rows($q)){
$_SESSION['admin']=$user;
header("location:dashboard.php");
}
else echo "Login gagal";
}
?>

<h2>Login Admin</h2>
<form method="POST">
Username:<input name="username"><br>
Password:<input type="password" name="password"><br>
<button name="login">Login</button>
</form>
