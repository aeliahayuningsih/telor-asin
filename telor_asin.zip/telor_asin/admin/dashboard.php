<?php
session_start();
if(!isset($_SESSION['admin'])) header('location:login.php');
?>
<h1>Dashboard Telur Asin</h1>
<a href="produk/index.php">Master Produk</a><br>
<a href="pesanan/index.php">Pesanan Konsumen</a>
